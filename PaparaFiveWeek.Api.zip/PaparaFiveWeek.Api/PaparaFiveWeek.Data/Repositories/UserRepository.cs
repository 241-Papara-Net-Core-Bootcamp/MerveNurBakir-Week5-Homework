﻿using Microsoft.EntityFrameworkCore;
using PaparaFiveWeek.Api.Controllers;
using PaparaFiveWeek.Data.Context;
using PaparaFiveWeek.Data.Interfaces;
using PaparaFiveWeek.Domain.Entities;
using PaparaFiveWeek.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PaparaFiveWeek.Data.Repositories
{
    public class UserRepository : GenericRepository<User>,IGenericRepository
    {
        private readonly DbSet<User> _users;
        public UserRepository(AppDbContext dbContext, Func<CacheTech, ICache> cacheService) : base(dbContext, cacheService)
        {
            _users = dbContext.Set<User>();
        }


    }
}
