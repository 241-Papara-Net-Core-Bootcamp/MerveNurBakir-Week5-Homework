﻿using Microsoft.EntityFrameworkCore;
using PaparaFiveWeek.Data.Context;
using PaparaFiveWeek.Data.Interfaces;
using PaparaFiveWeek.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PaparaFiveWeek.Data.Repositories
{
    public class Repository<T> : IRepository<T> where T : BaseEntity
    {
        private readonly AppDbContext _context;

        public Repository(AppDbContext context)
        {
            _context = context;
        }

        public List<T> Add(T entity)
        {
            entity.Id = 0; 
            if (entity == null)
            {
                throw new ArgumentNullException("entity");
            }
            _context.Set<T>().Add(entity);
            _context.SaveChanges();
            var cachedList = _context.Set<T>().ToList(); 
            return cachedList;
        }

        public IQueryable<T> GetAll()
        {
            return _context.Set<T>().AsQueryable();
        }

        public T GetById(int id)
        {
            return _context.Set<T>().Find(id);
        }
        public void Remove(T entity)
        {
            var modal = _context.Set<T>().Find(entity.Id);
            if (modal != null)
            {
                _context.Entry(modal).State = EntityState.Detached;
                _context.Set<T>().Remove(entity);
                _context.SaveChanges();
            }
        }
        public void Update(T entity)
        {
            var modal = _context.Set<T>().Find(entity.Id);
            if (modal != null)
            {
                _context.Entry(modal).State = EntityState.Detached;
                _context.Entry(entity).State = EntityState.Modified;
                _context.SaveChanges();
            }
        }
    }
}
