﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PaparaFiveWeek.Services.Interfaces
{
    public interface ICache
    {
        public bool TryGet<T>(string cacheKey, out List<T> value);
        public T Set<T>(string cacheKey, T value);
        public void Remove(string cacheKey);
    }
}
