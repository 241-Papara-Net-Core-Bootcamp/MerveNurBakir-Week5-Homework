﻿namespace PaparaFiveWeek.Api.Controllers
{
    public enum  CacheTech
    {
        Redis,
        Memory
    }
}