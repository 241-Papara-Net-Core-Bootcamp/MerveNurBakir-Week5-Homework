﻿using PaparaFiveWeek.Data.DTO;
using PaparaFiveWeek.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PaparaFiveWeek.Services.Interfaces
{
    public interface IUser
    {
            public void Add(UserDTO user);
           public List<User> GetUsers();
       
    }
}
