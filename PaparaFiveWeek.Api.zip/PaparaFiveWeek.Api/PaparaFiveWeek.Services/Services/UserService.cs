﻿using AutoMapper;
using PaparaFiveWeek.Data.DTO;
using PaparaFiveWeek.Data.Interfaces;
using PaparaFiveWeek.Domain.Entities;
using PaparaFiveWeek.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PaparaFiveWeek.Services.Services
{
    internal class UserService: IUser
    {
        private readonly IRepository<User> repository;
        private readonly ICache cacheService;
        private const string cacheKey = "PaparaCache"; 
        private readonly IMapper mapper;

        public UserService(IRepository<User> _repository, ICache _cacheService, IMapper _mapper)
        {
            repository = _repository;
            cacheService = _cacheService;
            mapper = _mapper;
        }
        public void Add(UserDTO userDTO)
        {
            var user = mapper.Map<User>(userDTO);
            var cachedList = repository.Add(user);
            //refresh cache 
            cacheService.Remove(cacheKey);
            cacheService.Set(cacheKey, cachedList);
        }

        public List<User> GetUsers()
        {
            var userList = repository.GetAll().ToList();
            cacheService.Set(cacheKey, userList);                   
            cacheService.TryGet<User>(cacheKey, out userList);         
            return userList;
        }
    }
}
