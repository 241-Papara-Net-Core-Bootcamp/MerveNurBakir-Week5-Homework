﻿using Hangfire;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using PaparaFiveWeek.Data.DTO;
using PaparaFiveWeek.Services.Interfaces;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System;
using System.Threading.Tasks;
using AutoMapper.Execution;
using AutoMapper;
using PaparaFiveWeek.Data.Interfaces;
using PaparaFiveWeek.Domain.Entities;

namespace PaparaFiveWeek.Api.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        public IRepository<User> _repository;
        Func<CacheTech, ICache> _cacheService;
        public IMapper mapper;

        public UserController(IRepository<User> repository, Func<CacheTech, ICache> cacheService, IMapper mapper)
        {
            _repository = repository;
            _cacheService = cacheService;
            this.mapper = mapper;
        }


        [HttpGet]
        public async Task DataFromApi()

        {
            HttpWebRequest httpWeb = (HttpWebRequest)WebRequest.Create("https://jsonplaceholder.typicode.com/posts ");
            httpWeb.Method = "GET";

            HttpWebResponse webResponse = (HttpWebResponse)httpWeb.GetResponse();
            Console.WriteLine(webResponse.StatusCode);
            Console.WriteLine(webResponse.Server);

            string Json;
            using (Stream stream = webResponse.GetResponseStream())
            {
                StreamReader reader = new StreamReader(stream, System.Text.Encoding.UTF8);
                Json = reader.ReadToEnd();
            }
            List<UserDTO> items = (List<UserDTO>)JsonConvert.DeserializeObject(Json, typeof(List<UserDTO>));
            var mapp = mapper.Map<List<User>>(items);
            foreach (var item in mapp)
            {
                _repository.Add(item);
            }

            Console.WriteLine(items);


        }
        [HttpPost]
        [Route("invoice")]
        public IActionResult Invoice()
        {
            RecurringJob.AddOrUpdate(() => DataFromApi(), "*/5 * * * * *");
            return Ok($" Repeat every 5 minutes!");
        }

    }
}
