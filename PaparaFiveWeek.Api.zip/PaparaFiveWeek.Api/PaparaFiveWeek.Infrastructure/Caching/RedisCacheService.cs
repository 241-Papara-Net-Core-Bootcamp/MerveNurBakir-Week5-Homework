﻿using PaparaFiveWeek.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PaparaFiveWeek.Infrastructure.Caching
{
    public class RedisCacheService : ICache
    {
        public void Remove(string cacheKey)
        {
            throw new NotImplementedException();
        }

        public T Set<T>(string cacheKey, T value)
        {
            throw new NotImplementedException();
        }

        public bool TryGet<T>(string cacheKey, out List<T> value)
        {
            throw new NotImplementedException();
        }
    }
}
